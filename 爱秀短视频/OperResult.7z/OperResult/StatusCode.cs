﻿namespace AiXiu.Model
{
    /// <summary>
    /// 返回结果状态码
    /// </summary>
    public enum StatusCode
    {
        Succeed,
        Failed,
        Wrong
    }
}